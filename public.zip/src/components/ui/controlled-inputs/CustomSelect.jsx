import { Controller } from "react-hook-form";
import Select, { components } from "react-select";
import { useState } from "react";

const CustomSelect = ({
  name,
  options = [],
  isLoading = false,
  isClearable = true,
  label,
  errors = {},
  control,
  rules = {},
  required = false,
  defaultValue,
  disabled = false,
  readOnly = false,
  isMulti = false,
  isNested = false,
}) => {
  const [openSubMenus, setOpenSubMenus] = useState({});
  const [menuIsOpen, setMenuIsOpen] = useState(false); // State to control menu open

  const validationRules = {
    ...rules,
    ...(required && { required: `${label} is required` }),
  };

  const toggleSubMenu = (optionId) => {
    setOpenSubMenus((prev) => ({
      ...prev,
      [optionId]: !prev[optionId],
    }));
  };

  const customStyles = {
    control: (provided, state) => ({
      ...provided,
      backgroundColor: disabled || readOnly ? "#f3f4f6" : "transparent",
      border: state.isFocused ? "1px solid #987d4a" : "1px solid #d1d5db",
      borderRadius: "8px",
      padding: "4px",
      boxShadow: "none",
      "&:hover": {
        border:
          disabled || readOnly ? "1px solid #d1d5db" : "1px solid #A1895A",
      },
      minHeight: "44px",
      opacity: disabled || readOnly ? 0.7 : 1,
      pointerEvents: readOnly ? "none" : "auto",
    }),
    menu: (provided) => ({
      ...provided,
      backgroundColor: "#fff",
      borderRadius: "8px",
      boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
      zIndex: 9999,
    }),
    option: (provided, state) => ({
      ...provided,
      backgroundColor: state.isFocused ? "#987d4a" : "transparent",
      color: state.isFocused ? "#fff" : "#000",
      padding: "10px",
      borderRadius: "4px",
      cursor: "pointer",
      position: "relative",
    }),
    multiValue: (provided) => ({
      ...provided,
      backgroundColor: "#f0f0f0",
      borderRadius: "4px",
    }),
    multiValueLabel: (provided) => ({
      ...provided,
      color: "#000",
    }),
    singleValue: (provided) => ({
      ...provided,
      color: "#000",
    }),
    placeholder: (provided) => ({
      ...provided,
      color: "#9CA3AF",
      fontSize: "0.875rem",
    }),
  };

  const formatNestedOptions = (options) =>
    options.map((option) => {
      if (option.subKeys) {
        return {
          ...option,
          options: Object.entries(option.subKeys).map(([key, value]) => ({
            value: `${option.value}.${key}`,
            label: `${option.label} - ${value.label}`,
            parentLabel: option.label,
            isSubOption: true,
          })),
        };
      }
      return option;
    });

  const findOptions = (value) => {
    if (value === undefined || value === null) return isMulti ? [] : null;

    if (isMulti) {
      if (!Array.isArray(value)) return [];
      return value
        .map((val) => {
          if (isNested && typeof val === "string" && val.includes(".")) {
            const [parent, child] = val.split(".");
            const parentOption = options.find((opt) => opt.value === parent);
            if (parentOption?.subKeys) {
              const childOption = Object.entries(parentOption.subKeys).find(
                ([key]) => key === child
              );
              if (childOption) {
                return {
                  value: `${parent}.${child}`,
                  label: `${parentOption.label} - ${childOption[1].label}`,
                  isSubOption: true,
                };
              }
            }
          }
          return options.find((opt) => opt.value === val) || null;
        })
        .filter(Boolean);
    } else {
      if (isNested && typeof value === "string" && value.includes(".")) {
        const [parent, child] = value.split(".");
        const parentOption = options.find((opt) => opt.value === parent);
        if (parentOption?.subKeys) {
          const childOption = Object.entries(parentOption.subKeys).find(
            ([key]) => key === child
          );
          if (childOption) {
            return {
              value: `${parent}.${child}`,
              label: `${parentOption.label} - ${childOption[1].label}`,
              isSubOption: true,
            };
          }
        }
      }
      return options.find((opt) => opt.value === value) || null;
    }
  };

  const handleChange = (selected, field) => {
    if (disabled || readOnly) return;
    if (isMulti) {
      field.onChange(selected ? selected.map((option) => option.value) : []);
      // Keep menu open if selecting a sub-option
      if (isNested && selected?.some((opt) => opt.isSubOption)) {
        setMenuIsOpen(true);
      }
    } else {
      field.onChange(selected?.value ?? null);
      setMenuIsOpen(false); // Close menu for single select
    }
  };

  const OptionComponent = ({ children, ...props }) => {
    const { data } = props;

    if (isNested && data.options) {
      return (
        <div>
          <div
            className="flex justify-between items-center"
            onClick={() => toggleSubMenu(data.value)}
          >
            <components.Option {...props}>{data.label}</components.Option>
            <span>{openSubMenus[data.value] ? "▲" : "▼"}</span>
          </div>
          {openSubMenus[data.value] && (
            <div className="pl-4">
              {data.options.map((subOption) => (
                <components.Option
                  key={subOption.value}
                  {...props}
                  data={subOption}
                >
                  {subOption.label}
                </components.Option>
              ))}
            </div>
          )}
        </div>
      );
    }
    return <components.Option {...props}>{children}</components.Option>;
  };

  // Custom filter to include parent label in search
  const filterOption = ({ label, data }, input) => {
    if (!input) return true;
    const searchText = input.toLowerCase();
    return (
      label.toLowerCase().includes(searchText) ||
      (data.parentLabel && data.parentLabel.toLowerCase().includes(searchText))
    );
  };

  return (
    <Controller
      name={name}
      control={control}
      rules={validationRules}
      defaultValue={defaultValue}
      render={({ field }) => (
        <div className="relative">
          <label
            htmlFor={name}
            className={`absolute text-sm text-gray-500 duration-300 transform -translate-y-4 scale-75 top-3 z-1 right-2 bg-light dark:bg-gray-900 px-3 ${
              disabled || readOnly ? "opacity-70" : ""
            } ${
              field.value
                ? "scale-75 -translate-y-5 text-main"
                : "scale-100 translate-y-0"
            }`}
          >
            {label}
          </label>
          <Select
            {...field}
            options={isNested ? formatNestedOptions(options) : options}
            styles={customStyles}
            placeholder={""}
            isLoading={isLoading}
            isClearable={isClearable && !disabled && !readOnly}
            value={findOptions(field.value)}
            onChange={(selected) => handleChange(selected, field)}
            onBlur={() => {
              field.onBlur();
              setMenuIsOpen(false); // Close menu on blur
            }}
            onMenuOpen={() => setMenuIsOpen(true)}
            onMenuClose={() => setMenuIsOpen(false)}
            menuIsOpen={menuIsOpen}
            classNamePrefix="react-select"
            menuPortalTarget={document.body}
            menuPosition="fixed"
            isDisabled={disabled || readOnly}
            isMulti={isMulti}
            closeMenuOnSelect={(selected) => {
              console.log("Selected:", selected); // Debug log
              if (isNested && selected?.data?.isSubOption) {
                return false; // Keep menu open for sub-options
              }
              return !isMulti; // Close menu for non-sub-options unless multi-select
            }}
            components={isNested ? { Option: OptionComponent } : undefined}
            filterOption={isNested ? filterOption : undefined}
          />
          {errors[name]?.message && (
            <p className="mt-1 text-xs text-red-500" role="alert">
              {errors[name].message}
            </p>
          )}
        </div>
      )}
    />
  );
};

export default CustomSelect;
