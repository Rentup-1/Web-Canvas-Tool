export type SmartFont =
  | { type: "fixed"; value: string }
  | { type: "branding"; key: string };
