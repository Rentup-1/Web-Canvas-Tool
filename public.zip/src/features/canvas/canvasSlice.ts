import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import { nanoid } from "nanoid";
import { type AspectRatio, type ElementType } from "./types";
import {
  type CanvasElement,
  type CanvasTextElement,
  type CanvasImageElement,
  type CircleShape,
  type RectangleShape,
  type EllipseShape,
  type LineShape,
  type TriangleShape,
  type StarShape,
  type CustomShape,
  type RegularPolygonShape,
  type ArcShape,
  type WedgeShape,
  type RingShape,
  type ArrowShape,
} from "./types";

interface CanvasState {
  elements: CanvasElement[];
  past: CanvasElement[][];
  future: CanvasElement[][];
  stageWidth: number;
  stageHeight: number;
  aspectRatio?: AspectRatio;
}

const initialState: CanvasState = {
  elements: [],
  past: [],
  future: [],
  stageWidth: 1000,
  stageHeight: 600,
  aspectRatio: "9:16",
};

const createBaseElement = (): Omit<CanvasElement, "type"> => ({
  id: nanoid(),
  x: 100,
  y: 100,
  width: 150,
  height: 100,
  rotation: 0,
  selected: false,
  fill: "#00A8E8",
  opacity: 1,
});

const canvasSlice = createSlice({
  name: "canvas",
  initialState,
  reducers: {
    addElement: (state, action: PayloadAction<{ type: ElementType }>) => {
      const base = createBaseElement();
      let newElement: CanvasElement;

      switch (action.payload.type) {
        case "text":
          newElement = {
            ...base,
            type: "text",
            text: "Edit me",
            fontSize: 24,
            fill: "#333",
            background: undefined,
            fontFamily: "Arial",
            padding: 0,
          } as CanvasTextElement;
          break;

        case "image":
          newElement = {
            ...base,
            type: "image",
            src: "",
          } as CanvasImageElement;
          break;

        case "circle":
          newElement = {
            ...base,
            type: "circle",
            radius: Math.min(base.width, base.height) / 2,
          } as CircleShape;
          break;

        case "rectangle":
          newElement = {
            ...base,
            type: "rectangle",
            cornerRadius: 0,
          } as RectangleShape;
          break;

        case "ellipse":
          newElement = {
            ...base,
            type: "ellipse",
            radiusX: base.width / 2,
            radiusY: base.height / 2,
          } as EllipseShape;
          break;

        case "line":
          newElement = {
            ...base,
            type: "line",
            points: [0, 0, base.width, base.height],
            stroke: "#000",
            strokeWidth: 2,
          } as LineShape;
          break;

        case "triangle":
          newElement = {
            ...base,
            type: "triangle",
            points: [0, base.height, base.width / 2, 0, base.width, base.height],
          } as TriangleShape;
          break;

        case "star":
          newElement = {
            ...base,
            type: "star",
            innerRadius: 20,
            outerRadius: 50,
            numPoints: 5,
          } as StarShape;
          break;

        case "regularPolygon":
          newElement = {
            ...base,
            type: "regularPolygon",
            sides: 6,
            radius: Math.min(base.width, base.height) / 2,
          } as RegularPolygonShape;
          break;

        case "arc":
          newElement = {
            ...base,
            type: "arc",
            innerRadius: 20,
            outerRadius: 50,
            angle: 60,
          } as ArcShape;
          break;

        case "wedge":
          newElement = {
            ...base,
            type: "wedge",
            radius: Math.min(base.width, base.height) / 2,
            angle: 60,
          } as WedgeShape;
          break;

        case "ring":
          newElement = {
            ...base,
            type: "ring",
            innerRadius: 20,
            outerRadius: 50,
          } as RingShape;
          break;

        case "arrow":
          newElement = {
            ...base,
            type: "arrow",
            points: [0, 0, base.width, base.height],
            pointerLength: 10,
            pointerWidth: 10,
            stroke: "#000",
            strokeWidth: 2,
          } as ArrowShape;
          break;

        case "custom":
          newElement = {
            ...base,
            type: "custom",
            points: [0, 0, base.width / 2, base.height, base.width, 0],
          } as CustomShape;
          break;

        default:
          throw new Error(`Unsupported element type: ${action.payload.type}`);
      }

      state.past.push(state.elements.map(el => ({ ...el })));
      state.future = [];
      state.elements.push(newElement);
    },

    addImageElement: (state, action: PayloadAction<{ src: string; width?: number; height?: number }>) => {
      const { src, width = 200, height = 200 } = action.payload;
      const newElement: CanvasImageElement = {
        ...createBaseElement(),
        type: "image",
        width,
        height,
        src,
      };

      state.past.push(state.elements.map(el => ({ ...el })));
      state.future = [];
      state.elements.push(newElement);
    },

    selectElement: (state, action: PayloadAction<string | null>) => {
      state.elements.forEach(el => {
        el.selected = el.id === action.payload;
      });
    },

    updateElement: (state, action: PayloadAction<{ id: string; updates: Partial<CanvasElement> }>) => {
      const { id, updates } = action.payload;
      const index = state.elements.findIndex(el => el.id === id);
      
      if (index !== -1) {
        state.past.push(state.elements.map(el => ({ ...el })));
        state.future = [];
        state.elements[index] = { ...state.elements[index], ...updates };
      }
    },

    deleteSelectedElement: (state) => {
      const selectedIndex = state.elements.findIndex(el => el.selected);
      if (selectedIndex !== -1) {
        state.past.push(state.elements.map(el => ({ ...el })));
        state.future = [];
        state.elements.splice(selectedIndex, 1);
      }
    },

    undo: (state) => {
      if (state.past.length > 0) {
        const previous = state.past.pop();
        if (previous) {
          state.future.unshift(state.elements.map(el => ({ ...el })));
          state.elements = previous;
        }
      }
    },

    redo: (state) => {
      if (state.future.length > 0) {
        const next = state.future.shift();
        if (next) {
          state.past.push(state.elements.map(el => ({ ...el })));
          state.elements = next;
        }
      }
    },

    moveElementUp: (state, action: PayloadAction<string>) => {
      const index = state.elements.findIndex(el => el.id === action.payload);
      if (index < state.elements.length - 1) {
        state.past.push(state.elements.map(el => ({ ...el })));
        state.future = [];
        [state.elements[index], state.elements[index + 1]] = [state.elements[index + 1], state.elements[index]];
      }
    },

    moveElementDown: (state, action: PayloadAction<string>) => {
      const index = state.elements.findIndex(el => el.id === action.payload);
      if (index > 0) {
        state.past.push(state.elements.map(el => ({ ...el })));
        state.future = [];
        [state.elements[index], state.elements[index - 1]] = [state.elements[index - 1], state.elements[index]];
      }
    },

    setStageSize: (state, action: PayloadAction<{ width: number; height: number }>) => {
      state.stageWidth = action.payload.width;
      state.stageHeight = action.payload.height;
    },

    setAspectRatio: (state, action: PayloadAction<AspectRatio | undefined>) => {
      state.aspectRatio = action.payload;
    },

    setElements: (state, action: PayloadAction<CanvasElement[]>) => {
      state.past.push(state.elements.map(el => ({ ...el })));
      state.future = [];
      state.elements = action.payload;
    },

    clearCanvas: (state) => {
      state.past.push(state.elements.map(el => ({ ...el })));
      state.future = [];
      state.elements = [];
    },
  },
});

export const {
  addElement,
  addImageElement,
  selectElement,
  updateElement,
  deleteSelectedElement,
  moveElementDown,
  moveElementUp,
  undo,
  redo,
  setStageSize,
  setAspectRatio,
  setElements,
  clearCanvas,
} = canvasSlice.actions;

export default canvasSlice.reducer;