declare module '@fontsource/*';
